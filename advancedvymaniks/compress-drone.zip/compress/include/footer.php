<footer class="new_footer_area bg_color">
		<div class="new_footer_top">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 foo mb-5">
						
						<div class="f_widget company_widget wow fadeInLeft" data-wow-delay="0.2s"
							style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInLeft;">
							<h3 class="f-title f_600 t_color f_size_18">Our Mission</h3>
							<p>Our mission is to utilize drones as first response for any situation and provide services where
								conventional methods have limited reach
								</p>
							
						</div>
					</div>
					<div class="col-lg-3 col-md-6 mb-5">
						<div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.4s"
							style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
							<h3 class="f-title f_600 t_color f_size_18">Navigation</h3>
							<ul class="list-unstyled f_list">
								<li><a href="http://advancedvymaniks.com/">Home</a></li>
								
								<li><a href="about-us.php">About Us</a></li>

								<li><a href="drone-repair.php">Drone Repairs</a></li>
								<li><a href="traning.php">Traning</a></li>
								<li><a href="contact.php">Contact</a></li>
								
								<li><a href="#">Privacy</a></li>


							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 mb-5">
						<div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.6s"
							style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
							<h3 class="f-title f_600 t_color f_size_18">Our Solutions</h3>
							<ul class="list-unstyled f_list">
								<li><a href="mapping.php">Mapping</a></li>
								<li><a href="medical-drone.php">Medical</a></li>
								<li><a href="firefighting-drone.php">Firefigthing</a></li>
								<li><a href="public-safety.php">public-safety</a></li>
								<li><a href="data-processing.php">Data processing</a></li>
								<li><a href="creative-content.php">Creative aerial content</a></li>
								<li><a href="agricultural-drone.php">Agricultural</a></li>
								<li><a href="transport.php">Transport</a></li>
								<li><a href="mining-drone.php">Mining</a></li>
								<li><a href="renewable-energy.php">Renewable-energy</a></li>
								<li><a href="utilities.php">Utilities</a></li>


								
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 mb-5">
						<div class="f_widget social-widget pl_70 wow fadeInLeft" data-wow-delay="0.8s"
							style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInLeft;">
							<h3 class="f-title f_600 t_color f_size_18">Contact Us</h3>
							
							<a href="
							mailto:info@advancedvymaniks.com" class="hi"><i class="fa fa-envelope-o" aria-hidden="true"></i> info@advancedvymaniks.com</a> <br>
						<a href="tel:+91-7259636477" class="hi"><i class="fa fa-phone" aria-hidden="true"></i>  +91-7259636477</a>
						<br>
						<a href="tel:+91-9483049611" class="hi"><i class="fa fa-phone" aria-hidden="true"></i> +91-9483049611</a>
						<br><br>
							<div class="f_social_icon">
								<a target="_blank" href="https://www.facebook.com/Advanced-Vymaniks-101994895338532/"  class="fa fa-facebook"></a>
								<a target="_blank" href="#" class="fa fa-twitter"></a>
								<a target="_blank" href="https://www.linkedin.com/company/72667930/admin/" class="fa fa-linkedin"></a>
								<a target="_blank" href="https://www.instagram.com/invites/contact/?i=1bw7sg0prjeh4&utm_content=lu2x7ai" class="fa fa-instagram"></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer_bg">
				<div class="footer_bg_one"></div>
				<div class="footer_bg_two"></div>
				<div class="footer_bg_two"></div>
			</div>
		</div>
		<div class="footer_bottom">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-6 col-sm-7">
						<p class="mb-0 f_400">Copyright© 2021 All rights reserved | <a href="http://advancedvymaniks.com/">Advancedvymaniks.com</a></p>
					</div>
					<div class="col-lg-6 col-sm-5 text-right">
						<!-- <p>Made By <i class="icon_heart"></i> in <a href="#">Atanu Jana</a></p> -->
					</div>
				</div>
			</div>
		</div>
	</footer>