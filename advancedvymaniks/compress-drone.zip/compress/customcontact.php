
<?php
session_start();
$con=mysqli_connect('localhost','root','');
if($con){
    ?>

    <script>
    //  alert('database is connected');
    
    </script>
    
    <?php

}
else{
echo"not connect";

}
mysqli_select_db($con,'drone');

if(isset($_POST['submit']))
{
    
    date_default_timezone_set('Asia/Kolkata');
   


$name=$_POST['name'];
$email=$_POST['email'];
$number=$_POST['number'];
$application=$_POST['application'];
$payload=$_POST['payload'];
$endurance=$_POST['endurance'];
$rangge=$_POST['rangge'];
$mode=$_POST['mode'];
$gimbal=$_POST['gimbal'];
$landing=$_POST['landing'];
$controller=$_POST['controller'];
$kit=$_POST['kit'];

if(file_exists($_FILES['files']['tmp_name']) || is_uploaded_file($_FILES['files']['tmp_name'])){

    $fileExtensionsAllowed = ['jpeg','jpg','png','docx','doc','pdf'];
    $files=$_FILES['files']['name'];
    $temp=$_FILES['files']['tmp_name'];
    $fileSize = $_FILES['files']['size'];
    $fileExtension = strtolower(end(explode('.',$files)));

    if (in_array($fileExtension,$fileExtensionsAllowed)) {
        
        
            if($fileSize>4000000)
            {
                ?>
            
            
                <script>
                alert("File exceeds maximum size (4MB)");
                window.open('drones.php','_self');
                
                </script>
                
                <?php
            }
        else{
                    $newfile = date('_mdYHis_');
                    $filename = $name.$newfile.$files;
                    
                    move_uploaded_file($temp,"uploads/$filename");






                

                        $to="atanuj383@gmail.com";
                        $subject="Email Send By " . $name . "for Custom Drone Design";
                        $message="
                         Email Send BY  $name,
                         Email :- $email,
                         Number :- $number,
                         Application :- $application,
                         payload :- $payload,
                         Endurance:- $endurance,
                         Range:- $rangge,
                         Mode:- $mode,
                         Gimbal:- $gimbal,
                         Landing:- $landing,
                         Controller:- $controller,
                         Kit:- $kit
                        

                        "
                        ;
                        $form=$email;
                        $headers= "Form : $form";

                        if(mail($to,$subject,$message,$headers))
                        {?>
                            <script>
                            alert('We get your message ,Please contact with +918552101842 number');
                            
                            </script>
                            <?php
                        }
                        else{
                            ?>
                            <script>
                            alert('mailed not send');
                            
                            </script>
                            <?php
                        }















                    
                    $qy="insert into custom_drone (name,email,number,application,payload,endurance,rangge,mode,gimbal,landing,controller,kit,files) values ('$name','$email','$number','$application','$payload','$endurance','$rangge','$mode','$gimbal','$landing','$controller','$kit','$filename')";
                    mysqli_query($con,$qy);
                    ?>
                
                
                <script>
                // alert("Your message is added");
                window.open('drones.php','_self');
                
                </script>
                
                <?php
                    
          }

  
      }
      
      else {
        ?>  
        <script>
            alert ("This file extension is not allowed. Please upload a JPEG or PNG or docx or pdf file");
            window.open('drones.php','_self');
        </script>


        <?php

      }
    
    
}
else{










                

    $to="atanuj383@gmail.com";
    $subject="Email Send By " . $name ;
    $message="
     Email Send BY  $name,
     Email :- $email,
     Number :- $number,
     Application :- $application,
     payload :- $payload,
     Endurance:- $endurance,
     Range:- $rangge,
     Mode:- $mode,
     Gimbal:- $gimbal,
     Landing:- $landing,
     Controller:- $controller,
     Kit:- $kit
    

    "
    ;
    $form=$email;
    $headers= "Form : $form";

    if(mail($to,$subject,$message,$headers))
    {?>
        <script>
        alert('We get your message ,Please contact with +91-7259636477 number');
        
        </script>
        <?php
    }
    else{
        ?>
        <script>
        alert('mailed not send');
        
        </script>
        <?php
    }











    $qy="insert into custom_drone (name,email,number,application,payload,endurance,rangge,mode,gimbal,landing,controller,kit) values ('$name','$email','$number','$application','$payload','$endurance','$rangge','$mode','$gimbal','$landing','$controller','$kit')";
    mysqli_query($con,$qy);
    ?>


<script>
// alert("Your message is added");
 window.open('drones.php','_self');

</script>

<?php
    
}








    
    
    
   









   
  

// `name`, `email`, `number`, `message`, `dates`

// mysqli_query($con,$qy);




}

?>










