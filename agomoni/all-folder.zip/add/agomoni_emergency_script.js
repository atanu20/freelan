const contacts = [
    {name: 'Suggestion 1'},
    {name: 'Suggestion 2'},
    {name: 'Suggestion 3'},
    {name: 'Another Suggestion'},
    {name: 'No suggestion'}
];

const searchBox = document.querySelector('.search-input');
const suggestionsPanel = document.querySelector('.suggestions');

searchBox.addEventListener('keyup', function(){
    const input = searchBox.value;
    suggestionsPanel.innerHTML = '';
    const sug = contacts.filter(function(contacts){
        return contacts.name.toLowerCase().startsWith(input);
    });
    sug.forEach(function(suggested){
        const div = document.createElement('div');
        div.innerHTML = suggested.name;
        suggestionsPanel.appendChild(div);
    });
    if(input == ''){
        suggestionsPanel.innerHTML = '';
    }
})