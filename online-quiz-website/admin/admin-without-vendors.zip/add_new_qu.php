<?php

session_start();
include"connection.php";
if(!isset($_SESSION['user']))
{
header('location:index.php');

}


$id=$_GET['id'];
$exam_categ=" ";
$sequery="SELECT * FROM `exam_category` WHERE id=$id";
                                                        $query=mysqli_query($con,$sequery);
                                                        $nums=mysqli_num_rows($query);

                                                        while($data= mysqli_fetch_array($query))
                                                        {
                                                    
                                                            $exam_categ=$data['category'];

                                                        }


?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin Panel</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./">Admin Panel</a>
                <a class="navbar-brand hidden" href="./">A</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="main.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="main.php"> <i class="menu-icon fa fa-dashboard"></i>Add and Edit </a>
                    </li>
                    <li>
                        <a href="add_question.php"> <i class="menu-icon fa fa-dashboard"></i>Add Questions</a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-close"></i>Logout</a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                

                <div class="col-sm-5 ">
                    <div class="user-area dropdown ">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        
                    </div>

                   

                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
           
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-6 ">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title text-danger">Add New Questions on <?php  echo $exam_categ;  ?></strong>
                            </div>
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                 
                                        <form action="" method="post" >
                                            
                                            <div class="form-group">
                                                <label  class="control-label mb-1">Add New Exam Questions</label>
                                                <input  name="ques" type="text" class="form-control" placeholder="Questions" required>
                                            </div>
                                            <div class="form-group">
                                                <label  class="control-label mb-1">First Option</label>
                                                <input  name="op1" type="text" class="form-control" placeholder="option 1" required>
                                            </div>
                                            <div class="form-group">
                                                <label  class="control-label mb-1">Second Option</label>
                                                <input  name="op2" type="text" class="form-control" placeholder="option 2" required>
                                            </div>
                                            <div class="form-group">
                                                <label  class="control-label mb-1">Third Option</label>
                                                <input  name="op3" type="text" class="form-control" placeholder="option 3" required>
                                            </div>
                                            <div class="form-group">
                                                <label  class="control-label mb-1">Four Option</label>
                                                <input  name="op4" type="text" class="form-control" placeholder="option 4" required>
                                            </div>
                                            <div class="form-group">
                                                <label  class="control-label mb-1">Answer</label>
                                                <input  name="ans" type="text" class="form-control" placeholder="Answer" required>
                                            </div>
                                           <input type="submit" name="add_qus" class="btn btn-success" value="Add Question">
                                               
                                                
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div> <!-- .card -->

                    </div>
                    
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Exam Category => <?php  echo $exam_categ; ?></strong>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Question no</th>
                                            <th scope="col">Question</th>
                                            
                                            <th scope="col">option1</th>
                                            <th scope="col">option2</th>
                                            <th scope="col">option3</th>
                                            <th scope="col">option4</th>
                                            <th scope="col">Answer</th>
                                            <th scope="col"colspan="2" >operation</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
 $sequery="SELECT * FROM `questions` WHERE category_ex='$exam_categ' ORDER BY qu_no ASC";
$query=mysqli_query($con,$sequery);
$nums=mysqli_num_rows($query);

while($data= mysqli_fetch_array($query))
{
  ?>

<tr>
                                            <td><?php echo $data['qu_no']; ?></td>
                                            <td><?php echo $data['question']; ?></td>
                                            <td><?php echo $data['op1']; ?></td>
                                            <td><?php echo $data['op2']; ?></td>
                                            <td><?php echo $data['op3']; ?></td>
                                            <td><?php echo $data['op4']; ?></td>
                                            <td><?php echo $data['answer']; ?></td>
                                           
                                            <td><a href="edit_old_qu.php?id=<?php echo $data['id']; ?>">Edit</a></td>
                                            <td><a href="delete_old_qu.php?id=<?php echo $data['id']; ?>" onclick=" return del()">Delete</a></td>
                                           
                                            
                                        </tr>

  <?php
                                      
} 

?>
                                            
                                            
                                       
                                          
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--/.col-->

                   </div>
                   </div>
        </div>
<script>

function del()
{

return confirm('Are u sure you want to delete this data???');

}


</script>
        </body>
        </html>

        <?php

if(isset($_POST['add_qus']))
{
   $question=$_POST['ques'];
   $op1=$_POST['op1'];
   $op2=$_POST['op2'];
   $op3=$_POST['op3'];
   $op4=$_POST['op4'];
   $ans=$_POST['ans'];


   $loop=0;

   $sequery="SELECT * FROM `questions` WHERE category_ex='$exam_categ' ORDER BY id ASC";
   $query=mysqli_query($con,$sequery);
   $nums=mysqli_num_rows($query);
   if($nums==0)
   {

   }
   else{
    while($data= mysqli_fetch_array($query))
    {
        $loop =$loop+1;
        $idth=$data['id'];
        $qy="update questions set qu_no='$loop' where id=$idth";


            mysqli_query($con,$qy);

    }
   }
   $loop = $loop+1;

$qy="insert into questions (qu_no, question, op1, op2, op3, op4, answer, category_ex) values('$loop','$question','$op1','$op2','$op3','$op4','$ans','$exam_categ')";

mysqli_query($con,$qy);
?>

<script>
    alert("Questions Insert Successfully");
    window.open('main.php','_self');
</script>
<?php

}
?>

