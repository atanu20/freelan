<?php
session_start();
include "connection.php";


$id=$_GET['id'];
$quuer="DELETE FROM `questions` WHERE id=$id";

$ru=mysqli_query($con,$quuer);

if($ru)
{
?>
<script>
alert('delete successfully');


</script>
<?php

}
else{
?>
<script>
alert("no delete");
</script>
<?php



}

header('location:main.php');



?>