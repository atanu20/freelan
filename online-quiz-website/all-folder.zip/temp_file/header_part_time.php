
<br><br><br><br>
<div class="container mt-5">
<div class="row">
<div class="col-md-8 col-12 mx-auto shadow p-2">
<p id="countdown" class="float-right p-3">countdown</p>
                

              </div>


</div>

</div>

<script>
setInterval(function() {
    timer();
}, 1000);
       function timer()
       {
            var  xmlhttp=new XMLHttpRequest();
            xmlhttp.onreadystatechange=function(){
                if(xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                   if(xmlhttp.responseText=="00:00:01")
                   {
                       window.location="result.php";
                   }
                   document.getElementById("countdown").innerHTML=xmlhttp.responseText;
                }
            };

            xmlhttp.open("GET","ajaxfile/load_timer.php",true);
        xmlhttp.send(null);

       };
       
    </script>